import json
import logging
import os
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
import math
from collections import defaultdict

# Configure logging
logger = logging.getLogger()
logger.setLevel(os.environ.get("LOG_LEVEL", "INFO"))

def calculate_prr(a, b, c, d):
    if a == 0:
        return None
    try:
        prr = (a/b)/(c/d)
        return prr
    except ZeroDivisionError:
        return None

def query_openfda(product_name, start_date, end_date):
    base_url = "https://api.fda.gov/drug/event.json"
    
    # Properly encode the product name for the URL
    encoded_product = urllib.parse.quote(product_name)
    
    # Construct the search query with proper encoding
    search_query = f'patient.drug.medicinalproduct:"{encoded_product}"+AND+receiptdate:[{start_date}+TO+{end_date}]'
    
    params = {
        "search": search_query,
        "limit": 100
    }
    
    url = f"{base_url}?{urllib.parse.urlencode(params)}"
    logger.info(f"OpenFDA API URL: {url}")
    
    try:
        headers = {
            "Accept": "application/json",
            "User-Agent": "SafetySignalDetectionAgent/1.0"
        }
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode())
            logger.info(f"OpenFDA API response: {len(data.get('results', []))} results found")
            return data
    except urllib.error.HTTPError as e:
        logger.error(f"OpenFDA API HTTP error: {e.code} - {e.reason}")
        if e.code == 404:
            return {"results": []}
        raise
    except Exception as e:
        logger.error(f"Error querying OpenFDA API: {str(e)}")
        raise

def analyze_trends(data):
    daily_counts = defaultdict(int)
    for report in data["results"]:
        date = report.get("receiptdate", "").split("T")[0]
        if date:
            daily_counts[date] += 1

    dates = sorted(daily_counts.keys())
    moving_average = {}
    for i, date in enumerate(dates):
        if i >= 3 and i < len(dates) - 3:
            window_sum = sum(daily_counts[dates[j]] for j in range(i-3, i+4))
            moving_average[date] = round(window_sum / 7, 2)

    return {
        "daily_counts": dict(daily_counts),
        "moving_average": moving_average
    }

def detect_signals(data, threshold=2.0):
    signals = []
    total_drug_reports = len(data["results"])
    events = {}
    for report in data["results"]:
        for event in report.get("patient", {}).get("reaction", []):
            event_term = event.get("reactionmeddrapt", "")
            if event_term:
                events[event_term] = events.get(event_term, 0) + 1
    
    for event, count in events.items():
        background_rate = 0.01
        total_background = 1000000
        prr = calculate_prr(
            count,
            total_drug_reports,
            background_rate * total_background,
            total_background
        )
        if prr and prr >= threshold:
            signals.append({
                "event": event,
                "count": count,
                "prr": round(prr, 2),
                "confidence_interval": calculate_confidence_interval(count, total_drug_reports)
            })
    return sorted(signals, key=lambda x: x["prr"], reverse=True)

def calculate_confidence_interval(count, total):
    if total == 0:
        return None
    proportion = count / total
    z = 1.96
    try:
        standard_error = math.sqrt((proportion * (1 - proportion)) / total)
        ci_lower = max(0, proportion - z * standard_error)
        ci_upper = min(1, proportion + z * standard_error)
        return {
            "lower": round(ci_lower, 3),
            "upper": round(ci_upper, 3)
        }
    except:
        return None

def lambda_handler(event, context):
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Extract parameters from Bedrock Agent event format
        parameters = {param["name"]: param["value"] for param in event.get("parameters", [])}
        product_name = parameters.get("product_name")
        time_period = int(parameters.get("time_period", 6))
        signal_threshold = float(parameters.get("signal_threshold", 2.0))
        
        if not product_name:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Product name is required"
                })
            }
        
        # Use 2025-04-28 as end date (latest available data in OpenFDA)
        end_date = datetime(2025, 4, 28)
        start_date = end_date - timedelta(days=30*time_period)
        data = query_openfda(
            product_name,
            start_date.strftime("%Y%m%d"),
            end_date.strftime("%Y%m%d")
        )
        
        if not data.get("results"):
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": f"No adverse event reports found for {product_name}"
                })
            }
        
        trends = analyze_trends(data)
        signals = detect_signals(data, signal_threshold)
        
        response = {
            "product_name": product_name,
            "analysis_period": {
                "start": start_date.isoformat(),
                "end": end_date.isoformat()
            },
            "total_reports": len(data["results"]),
            "trends": trends,
            "signals": signals[:10]
        }
        
        return {
            "statusCode": 200,
            "body": json.dumps(response)
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": f"Internal server error: {str(e)}"
            })
        }
