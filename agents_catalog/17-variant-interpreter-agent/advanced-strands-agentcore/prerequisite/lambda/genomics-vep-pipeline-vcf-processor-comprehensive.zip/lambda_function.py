import json
import boto3
import os
import re
from datetime import datetime
import uuid
import time

def lambda_handler(event, context):
    omics = boto3.client('omics')
    dynamodb = boto3.client('dynamodb')
    s3 = boto3.client('s3')
        
    WORKFLOW_ID = os.environ['WORKFLOW_ID']
    ROLE_ARN = os.environ['ROLE_ARN']
    OUTPUT_URI = os.environ['OUTPUT_URI']
    DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']
    BATCH_SIZE = int(os.environ.get('BATCH_SIZE', '20'))
    ALLOWED_PREFIXES = os.environ.get('ALLOWED_PREFIXES', '').split(',') if os.environ.get('ALLOWED_PREFIXES') else []
    
    try:
        # Collect VCF files from S3 events
        vcf_files = []
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            
            if not (key.endswith('.vcf') or key.endswith('.vcf.gz')):
                continue
            
            if ALLOWED_PREFIXES and ALLOWED_PREFIXES[0]:
                if not any(key.startswith(p.strip()) for p in ALLOWED_PREFIXES):
                    continue
            
            vcf_files.append({'bucket': bucket, 'key': key})
        
        # Discover additional VCFs for batch processing
        if len(vcf_files) == 1:
            additional_vcfs = discover_batch_vcfs(s3, vcf_files[0], BATCH_SIZE)
            vcf_files.extend(additional_vcfs)
        
        print(f"Processing {len(vcf_files)} VCF files in batches of {BATCH_SIZE}")
        
        # Process in batches
        batch_id = str(uuid.uuid4())[:8]
        processed_count = 0
        
        for i in range(0, len(vcf_files), BATCH_SIZE):
            batch = vcf_files[i:i + BATCH_SIZE]
            batch_number = (i // BATCH_SIZE) + 1
            
            print(f"Processing batch {batch_number} with {len(batch)} files")
            
            for vcf_file in batch:
                if process_vcf_file(omics, dynamodb, vcf_file, WORKFLOW_ID, ROLE_ARN, OUTPUT_URI, DYNAMODB_TABLE, batch_id, batch_number, context):
                    processed_count += 1
            
            time.sleep(1)  # Brief pause between batches
        
        # Record batch summary
        record_batch_summary(dynamodb, DYNAMODB_TABLE, batch_id, len(vcf_files), processed_count)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'batch_id': batch_id,
                'total_files': len(vcf_files),
                'processed_files': processed_count
            })
        }
        
    except Exception as e:
        print(f"Error: {e}")
        return {'statusCode': 500, 'body': json.dumps(f'Error: {str(e)}')}

def discover_batch_vcfs(s3, initial_vcf, batch_size):
    additional_vcfs = []
    try:
        bucket = initial_vcf['bucket']
        key = initial_vcf['key']
        prefix = '/'.join(key.split('/')[:-1]) + '/' if '/' in key else ''
        
        if prefix:
            response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=batch_size * 2)
            for obj in response.get('Contents', []):
                obj_key = obj['Key']
                if obj_key != key and (obj_key.endswith('.vcf') or obj_key.endswith('.vcf.gz')):
                    additional_vcfs.append({'bucket': bucket, 'key': obj_key})
                    if len(additional_vcfs) >= batch_size - 1:
                        break
    except Exception as e:
        print(f"Error discovering batch VCFs: {e}")
    return additional_vcfs

def process_vcf_file(omics, dynamodb, vcf_file, workflow_id, role_arn, output_uri, table_name, batch_id, batch_number, context):
    try:
        bucket = vcf_file['bucket']
        key = vcf_file['key']
        filename = key.split('/')[-1]
        #sample_id = re.sub(r'[^a-zA-Z0-9-_]', '-', filename.replace('.vcf.gz', '').replace('.vcf', ''))
        sample_id = filename.split('.')[0]
        prefix = '/'.join(key.split('/')[:-1]) if '/' in key else ''
        
        # Check if already processed
        existing = dynamodb.get_item(TableName=table_name, Key={'SampleID': {'S': sample_id}})
        if 'Item' in existing:
            print(f"Sample {sample_id} already processed")
            return False
        
        # Start VEP workflow
        run_response = omics.start_run(
            workflowId=workflow_id,
            roleArn=role_arn,
            name=f"vep-batch-{batch_id}-{sample_id}",
            outputUri=f"{output_uri}/{sample_id}/",
            parameters={
                "id": sample_id,
                "vcf": f"s3://{bucket}/{key}",
                "vep_species": "homo_sapiens",
                "vep_cache": "s3://omics-us-prod/vep_cache/",
                "vep_cache_version": "113",
                "ecr_registry": f"{os.environ['ACCOUNT_ID']}.dkr.ecr.{os.environ['AWS_REGION']}.amazonaws.com",
                "vep_genome": "GRCh38"
            },
            storageType='STATIC'
        )
        
        # Record in DynamoDB
        dynamodb.put_item(
            TableName=table_name,
            Item={
                'SampleID': {'S': sample_id},
                'WorkflowRunID': {'S': run_response['id']},
                'BatchID': {'S': batch_id},
                'BatchNumber': {'N': str(batch_number)},
                'InputVCF': {'S': f"s3://{bucket}/{key}"},
                'S3Bucket': {'S': bucket},
                'S3Key': {'S': key},
                'S3Prefix': {'S': prefix},
                'OriginalFilename': {'S': filename},
                'Status': {'S': 'RUNNING'},
                'StartTime': {'S': datetime.utcnow().isoformat()},
                'OutputPath': {'S': f"{output_uri}/{sample_id}/"},
                'ProcessingStage': {'S': 'VEP_WORKFLOW'}
            }
        )
        
        print(f"Started workflow {run_response['id']} for sample {sample_id}")
        return True
        
    except Exception as e:
        print(f"Error processing {vcf_file['key']}: {e}")
        return False

def record_batch_summary(dynamodb, table_name, batch_id, total_files, processed_files):
    try:
        dynamodb.put_item(
            TableName=table_name,
            Item={
                'SampleID': {'S': f"BATCH_SUMMARY_{batch_id}"},
                'BatchID': {'S': batch_id},
                'TotalFiles': {'N': str(total_files)},
                'ProcessedFiles': {'N': str(processed_files)},
                'Status': {'S': 'BATCH_INITIATED'},
                'StartTime': {'S': datetime.utcnow().isoformat()},
                'ProcessingStage': {'S': 'BATCH_SUMMARY'}
            }
        )
    except Exception as e:
        print(f"Error recording batch summary: {e}")
