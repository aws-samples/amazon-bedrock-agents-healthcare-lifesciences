#!/usr/bin/env python3

import json
import boto3
import os
import re
import uuid
from datetime import datetime

# Environment variables
ROLE_ARN = os.environ.get('ROLE_ARN')
VARIANT_STORE_NAME = os.environ.get('VARIANT_STORE_NAME')
ANNOTATION_STORE_NAME = os.environ.get('ANNOTATION_STORE_NAME')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE')
DATABASE_NAME = os.environ.get('DATABASE_NAME')

# Initialize clients
omics_client = boto3.client('omics')
s3_client = boto3.client('s3')
dynamodb_client = boto3.client('dynamodb')
lakeformation = boto3.client('lakeformation')
glue = boto3.client('glue')

def lambda_handler(event, context):
    print(f"Received event: {json.dumps(event, default=str)}")
    
    try:
        # Handle S3 event (for VEP output files)
        if 'Records' in event and event['Records'] and 's3' in event['Records'][0]:
            return handle_s3_event(event)
        
        # Handle EventBridge event (for workflow completion)
        elif event.get('source') == 'aws.omics':
            if event.get('detail-type') == 'HealthOmics Run Status Change':
                return handle_workflow_event(event)
            elif event.get('detail-type') == 'HealthOmics Variant Import Job Status Change':
                return handle_import_completion(event)
        
        else:
            print("Unsupported event type")
            return {'statusCode': 200, 'body': 'Event ignored'}
            
    except Exception as e:
        print(f"Error in lambda_handler: {str(e)}")
        return {'statusCode': 500, 'body': f'Error: {str(e)}'}

def handle_s3_event(event):
    """Handle S3 event when a VEP output file is uploaded"""
    try:
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        print(f"Processing S3 event for {bucket}/{key}")
        
        # FIXED: Updated pattern matching for VEP annotated output files
        # Check for .ann.vcf.gz files in annotation directories
        if not (key.endswith('.ann.vcf.gz') and '/annotation/' in key):
            print(f"Not a VEP annotated output file: {key}")
            return {'statusCode': 200, 'body': 'Not a VEP annotated output'}
        
        # FIXED: More flexible sample name extraction
        # Handle multiple path patterns:
        # Pattern 1: /NA21135/5101578/pubdir/annotation/NA21135/NA21135.ann.vcf.gz
        # Pattern 2: /sample_name/annotation/sample_name.ann.vcf.gz
        # Pattern 3: annotation/sample_name/sample_name.ann.vcf.gz
        
        sample_name = None
        
        # Try pattern 1: /SAMPLE/NUMBER/pubdir/annotation/SAMPLE/SAMPLE.ann.vcf.gz
        match1 = re.search(r'/([^/]+)/\d+/pubdir/annotation/([^/]+)/\2\.ann\.vcf\.gz$', key)
        if match1:
            sample_name = match1.group(1)
            print(f"Extracted sample name using pattern 1: {sample_name}")
        
        # Try pattern 2: /SAMPLE/annotation/SAMPLE.ann.vcf.gz
        if not sample_name:
            match2 = re.search(r'/([^/]+)/annotation/\1\.ann\.vcf\.gz$', key)
            if match2:
                sample_name = match2.group(1)
                print(f"Extracted sample name using pattern 2: {sample_name}")
        
        # Try pattern 3: annotation/SAMPLE/SAMPLE.ann.vcf.gz
        if not sample_name:
            match3 = re.search(r'annotation/([^/]+)/\1\.ann\.vcf\.gz$', key)
            if match3:
                sample_name = match3.group(1)
                print(f"Extracted sample name using pattern 3: {sample_name}")
        
        # Try pattern 4: Extract from filename if all else fails
        if not sample_name:
            filename = key.split('/')[-1]
            if filename.endswith('.ann.vcf.gz'):
                sample_name = filename.replace('.ann.vcf.gz', '')
                print(f"Extracted sample name from filename: {sample_name}")
        
        if not sample_name:
            print(f"Could not extract sample name from: {key}")
            return {'statusCode': 400, 'body': 'Could not extract sample name'}
        
        print(f"Starting variant import for sample: {sample_name}")
        
        # Start variant import job
        import_job_id = start_variant_import(bucket, key, sample_name)
        
        # Update DynamoDB
        update_dynamodb_import_status(sample_name, import_job_id, construct_s3_path(bucket, key))
        
        return {
            'statusCode': 200,
            'body': f"Started variant import {import_job_id} for {sample_name}"
        }
        
    except Exception as e:
        print(f"Error in handle_s3_event: {str(e)}")
        return {'statusCode': 500, 'body': f'S3 event error: {str(e)}'}

def handle_workflow_event(event):
    """Handle HealthOmics workflow completion events"""
    try:
        detail = event.get('detail', {})
        run_id = detail.get('runId')
        status = detail.get('status')
        
        print(f"Workflow {run_id} completed with status: {status}")
        
        if status == 'COMPLETED':
            # This is a backup path - the S3 event should handle most cases
            print(f"Workflow completed: {run_id}")
            return {'statusCode': 200, 'body': f'Workflow completed: {run_id}'}
        else:
            print(f"Workflow failed: {run_id} with status {status}")
            return {'statusCode': 200, 'body': f'Workflow failed: {run_id}'}
            
    except Exception as e:
        print(f"Error in handle_workflow_event: {str(e)}")
        return {'statusCode': 500, 'body': f'Workflow event error: {str(e)}'}

def handle_import_completion(event):
    """Handle variant import completion and setup Lake Formation"""
    try:
        detail = event.get('detail', {})
        job_id = detail.get('jobId')
        status = detail.get('status')
        
        print(f"Import job {job_id} completed with status: {status}")
        
        if status == 'COMPLETED':
            # Setup Lake Formation database and permissions
            setup_lake_formation_database()
            
            # Update DynamoDB
            update_import_completion_in_db(job_id, status)
            
            print(f"✅ Pipeline completed for import job {job_id}")
            return {'statusCode': 200, 'body': f'Pipeline completed for {job_id}'}
        else:
            print(f"❌ Import job {job_id} failed with status {status}")
            update_import_completion_in_db(job_id, status)
            return {'statusCode': 200, 'body': f'Import job failed: {job_id}'}
            
    except Exception as e:
        print(f"Error in handle_import_completion: {str(e)}")
        return {'statusCode': 500, 'body': f'Import completion error: {str(e)}'}

def construct_s3_path(bucket, key):
    """
    Construct a proper S3 path, removing any double slashes
    FIXED: Better handling of leading slashes in keys
    """
    # Key is already clean (no leading slash from workflow environment variable)
    clean_key = key
    
    # Construct the S3 path
    s3_path = f"s3://{bucket}/{clean_key}"
    
    print(f"Original key: '{key}' -> Clean S3 path: '{s3_path}'")
    return s3_path

def start_variant_import(bucket, key, sample_name):
    """Start variant import job - IMPROVED ERROR HANDLING AND PATH CONSTRUCTION"""
    try:
        # Construct proper S3 path
        s3_path = construct_s3_path(bucket, key)
        
        print(f"🔄 Attempting to start variant import for {sample_name}")
        print(f"   Source: {s3_path}")
        print(f"   Destination: {VARIANT_STORE_NAME}")
        print(f"   Role: {ROLE_ARN}")
        
        # Verify the S3 object exists before starting import
        try:
            clean_key = key
            s3_client.head_object(Bucket=bucket, Key=clean_key)
            print(f"✅ Verified S3 object exists: s3://{bucket}/{clean_key}")
        except Exception as s3_error:
            print(f"❌ S3 object verification failed: {s3_error}")
            raise Exception(f"S3 object does not exist: s3://{bucket}/{clean_key}")
        
        # FIXED: Get the variant store reference information
        try:
            variant_store_info = omics_client.get_variant_store(name=VARIANT_STORE_NAME)
            reference_arn = variant_store_info['reference']['referenceArn']
            print(f"📋 Variant store reference: {reference_arn}")
        except Exception as ref_error:
            print(f"❌ Error getting variant store reference: {ref_error}")
            raise Exception(f"Could not get variant store reference: {ref_error}")
        
        response = omics_client.start_variant_import_job(
            destinationName=VARIANT_STORE_NAME,
            roleArn=ROLE_ARN,
            items=[
                {
                    'source': s3_path
                }
            ],
            runLeftNormalization=True,
            annotationFields={
                'VEP': 'CSQ'
            }
        )
        
        print(f"📋 API Response: {json.dumps(response, default=str)}")
        
        # Check if response has the expected structure
        if 'jobId' in response:
            import_job_id = response['jobId']
            print(f"✅ Started variant import job: {import_job_id}")
            return import_job_id
        else:
            print(f"❌ Unexpected response structure: {response}")
            raise Exception(f"API response missing 'jobId' field: {response}")
        
    except Exception as e:
        print(f"❌ Detailed error starting variant import:")
        print(f"   Error type: {type(e).__name__}")
        print(f"   Error message: {str(e)}")
        print(f"   Sample: {sample_name}")
        print(f"   Source: {construct_s3_path(bucket, key)}")
        print(f"   Variant Store: {VARIANT_STORE_NAME}")
        
        # Check if variant store exists
        try:
            stores_response = omics_client.list_variant_stores()
            store_names = [store['name'] for store in stores_response.get('variantStores', [])]
            print(f"   Available variant stores: {store_names}")
            
            if VARIANT_STORE_NAME not in store_names:
                print(f"   ❌ Variant store '{VARIANT_STORE_NAME}' not found!")
        except Exception as store_error:
            print(f"   Error checking variant stores: {store_error}")
        
        raise e

def setup_lake_formation_database():
    """Setup Lake Formation database and permissions"""
    try:
        # Create database if it doesn't exist
        try:
            glue.get_database(Name=DATABASE_NAME)
            print(f"Database {DATABASE_NAME} already exists")
        except glue.exceptions.EntityNotFoundException:
            glue.create_database(
                DatabaseInput={
                    'Name': DATABASE_NAME,
                    'Description': 'Genomics agent database for variant analysis',
                    'Parameters': {
                        'classification': 'genomics',
                        'purpose': 'agent-queries',
                        'created_by': 'genomics-pipeline'
                    }
                }
            )
            print(f"✅ Created database: {DATABASE_NAME}")
        
        # Get account ID
        sts = boto3.client('sts')
        account_id = sts.get_caller_identity()['Account']
        
        # Grant database permissions
        try:
            lakeformation.grant_permissions(
                Principal={'DataLakePrincipalIdentifier': f'arn:aws:iam::{account_id}:root'},
                Resource={'Database': {'Name': DATABASE_NAME}},
                Permissions=['ALL'],
                PermissionsWithGrantOption=['ALL']
            )
            print(f"✅ Granted database permissions for {DATABASE_NAME}")
        except Exception as e:
            print(f"Database permissions (may already exist): {e}")
        
        # Grant table permissions for variant store tables
        variant_tables = [
            f"{VARIANT_STORE_NAME}_variants",
            f"{VARIANT_STORE_NAME}_annotations"
        ]
        
        for table_name in variant_tables:
            try:
                lakeformation.grant_permissions(
                    Principal={'DataLakePrincipalIdentifier': f'arn:aws:iam::{account_id}:root'},
                    Resource={
                        'Table': {
                            'DatabaseName': DATABASE_NAME,
                            'Name': table_name
                        }
                    },
                    Permissions=['SELECT', 'DESCRIBE'],
                    PermissionsWithGrantOption=['SELECT', 'DESCRIBE']
                )
                print(f"✅ Granted permissions on table: {table_name}")
            except Exception as e:
                print(f"Table {table_name} permissions: {e}")
        
        print(f"✅ Lake Formation setup completed for {DATABASE_NAME}")
        
    except Exception as e:
        print(f"Error in Lake Formation setup: {str(e)}")
        # Don't raise - this shouldn't fail the entire pipeline

def update_dynamodb_import_status(sample_name, import_job_id, s3_path):
    """Update DynamoDB with import job information"""
    try:
        dynamodb_client.update_item(
            TableName=DYNAMODB_TABLE,
            Key={'SampleID': {'S': sample_name}},
            UpdateExpression='SET ImportJobID = :job_id, AnnotatedVCFPath = :path, ProcessingStage = :stage, ImportStartTime = :time',
            ExpressionAttributeValues={
                ':job_id': {'S': import_job_id},
                ':path': {'S': s3_path},
                ':stage': {'S': 'VARIANT_IMPORT'},
                ':time': {'S': datetime.utcnow().isoformat()}
            }
        )
        print(f"Updated DynamoDB for sample {sample_name} with import job {import_job_id}")
    except Exception as e:
        print(f"Error updating DynamoDB: {str(e)}")

def update_import_completion_in_db(job_id, status):
    """Update import completion status in DynamoDB"""
    try:
        # Find the record by ImportJobID
        scan_response = dynamodb_client.scan(
            TableName=DYNAMODB_TABLE,
            FilterExpression='ImportJobID = :job_id',
            ExpressionAttributeValues={':job_id': {'S': job_id}}
        )
        
        if scan_response['Items']:
            item = scan_response['Items'][0]
            sample_id = item['SampleID']['S']
            
            stage = 'COMPLETED' if status == 'COMPLETED' else 'IMPORT_FAILED'
            
            dynamodb_client.update_item(
                TableName=DYNAMODB_TABLE,
                Key={'SampleID': {'S': sample_id}},
                UpdateExpression='SET ProcessingStage = :stage, ImportEndTime = :time, FinalStatus = :final_status',
                ExpressionAttributeValues={
                    ':stage': {'S': stage},
                    ':time': {'S': datetime.utcnow().isoformat()},
                    ':final_status': {'S': status}
                }
            )
            print(f"Updated import completion for {sample_id}: {status}")
    except Exception as e:
        print(f"Error updating import completion: {str(e)}")
