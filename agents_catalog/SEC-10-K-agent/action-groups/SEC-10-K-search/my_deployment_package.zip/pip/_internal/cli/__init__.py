"""Subpackage containing all of pip's command line interface related code
"""

# This file intentionally does not import submodules
