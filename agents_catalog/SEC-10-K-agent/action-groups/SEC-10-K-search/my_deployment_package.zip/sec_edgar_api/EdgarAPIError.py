class EdgarAPIError(Exception):
    """SEC EDGAR API error."""
