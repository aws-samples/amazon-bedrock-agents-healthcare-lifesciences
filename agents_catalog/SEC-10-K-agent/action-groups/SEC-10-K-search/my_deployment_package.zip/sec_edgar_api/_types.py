from typing import Any, Dict, List

JSONType = Dict[str, Any]

SubmissionsType = Dict[str, List[str]]
