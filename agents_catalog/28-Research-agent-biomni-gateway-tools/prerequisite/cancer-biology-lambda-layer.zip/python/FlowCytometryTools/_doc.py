"""
A package for analyzing flow cytometry tools.
"""
